"""One request and one bounded frame in flight on a separate TCP connection."""

import struct
import time


class VideoChannel:
    def __init__(self):
        self.client = None
        self.output = memoryview(b"")
        self.requested_at = None
        self.activity = 0.0

    def attach(self, client):
        self.close()
        self.client = client
        self.output = memoryview(b"BRV1")
        self.activity = time.monotonic()

    def close(self):
        if self.client is not None:
            self.client.close()
        self.client = None
        self.output = memoryview(b"")
        self.requested_at = None

    def respond(self, frame=b""):
        self.output = memoryview(struct.pack(">I", len(frame)) + frame)
        self.requested_at = None

    def poll(self):
        if self.client is None:
            return
        now = time.monotonic()
        if now - self.activity > 6:
            self.close()
            return
        try:
            try:
                data = self.client.recv(16)
                if data != b"f" or self.requested_at is not None or self.output:
                    self.close()
                    return
                self.requested_at = now
                self.activity = now
            except BlockingIOError:
                pass
            if self.requested_at is not None and now - self.requested_at > 0.7:
                self.respond()
            if self.output:
                try:
                    sent = self.client.send(self.output)
                    self.output = self.output[sent:]
                except BlockingIOError:
                    pass
        except OSError:
            self.close()
