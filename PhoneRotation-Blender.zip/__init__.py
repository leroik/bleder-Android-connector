bl_info = {
    "name": "Phone Rotation",
    "author": "Phone Rotation contributors",
    "version": (1, 4, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar > Phone Rotation",
    "description": "Rotate an object from an Android phone on the local network",
    "category": "3D View",
}

import struct
import tempfile
import time
import zlib
from pathlib import Path

import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
from mathutils import Quaternion

from .camera_preview import CameraPreview, png_chunk
from .qrcodegen import QrCode
from .receiver import Receiver, default_address

_receiver = None
_previews = None
_qr_directory = None
_scene = None
_target_id = None
_anchor = None
_camera_target = False
_camera_preview = CameraPreview()
_draw_handle = None


def _object_quaternion(obj):
    if obj.rotation_mode == "QUATERNION":
        return obj.rotation_quaternion.copy()
    if obj.rotation_mode == "AXIS_ANGLE":
        angle, x, y, z = obj.rotation_axis_angle
        return Quaternion((x, y, z), angle)
    return obj.rotation_euler.to_quaternion()


def _set_quaternion(obj, rotation):
    if obj.rotation_mode == "QUATERNION":
        obj.rotation_quaternion = rotation
    elif obj.rotation_mode == "AXIS_ANGLE":
        axis, angle = rotation.to_axis_angle()
        obj.rotation_axis_angle = (angle, *axis)
    else:
        obj.rotation_euler = rotation.to_euler(obj.rotation_mode, obj.rotation_euler)


def _command(action, values):
    global _anchor, _target_id, _camera_target
    if action in {"begin", "begin-camera"}:
        _anchor = None
        _target_id = None
        _camera_target = action == "begin-camera"
    obj = None
    if _scene is not None:
        obj = _scene.camera if _camera_target else _scene.phone_rotation.target
    if obj is None or not obj.is_editable:
        _anchor = None
        _target_id = None
        return b"no-target"
    if _anchor is None or _target_id != obj.session_uid:
        _anchor = _object_quaternion(obj)
        _target_id = obj.session_uid
    if values is not None:
        _set_quaternion(obj, _anchor @ Quaternion(values).normalized())
    if action == "stop":
        _anchor = None
        _target_id = None
        _camera_target = False
    return b"ok"


def _redraw():
    if bpy.context.window_manager:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()


def _draw_camera():
    if _receiver is not None:
        _camera_preview.capture(bpy.context, _scene, _receiver.video)


def _tick():
    if _receiver is None:
        return None
    connected = _receiver.authenticated
    _receiver.poll()
    video = _receiver.video
    if video.client is None and _camera_preview.offscreen is not None:
        _camera_preview.close()
    if video.requested_at is None:
        _camera_preview.redraw_pending = False
    if (_receiver.authenticated != connected or
            (video.requested_at is not None and not _camera_preview.redraw_pending
             and time.monotonic() >= _camera_preview.next_frame)):
        _camera_preview.redraw_pending = video.requested_at is not None
        _redraw()
    return 1 / 90


def _stop():
    global _receiver, _scene, _anchor, _target_id, _qr_directory, _camera_target, _draw_handle
    if _receiver is not None:
        _receiver.close()
        _receiver = None
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
        _draw_handle = None
    _camera_preview.close()
    _camera_preview.redraw_pending = False
    _camera_preview.next_frame = 0
    _camera_target = False
    _scene = None
    _anchor = None
    _target_id = None
    if _previews is not None:
        _previews.clear()
    if _qr_directory is not None:
        _qr_directory.cleanup()
        _qr_directory = None
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)


@persistent
def _before_file_load(_):
    _stop()


def _qr_png(code):
    qr = QrCode.encode_text(code, QrCode.Ecc.MEDIUM)
    scale = 6
    width = (qr.get_size() + 8) * scale
    rows = bytearray()
    for y in range(-4, qr.get_size() + 4):
        row = b"".join(
            (b"\x00" if qr.get_module(x, y) else b"\xff") * scale
            for x in range(-4, qr.get_size() + 4)
        )
        rows.extend((b"\x00" + row) * scale)
    header = struct.pack(">IIBBBBB", width, width, 8, 0, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", header)
            + png_chunk(b"IDAT", zlib.compress(rows)) + png_chunk(b"IEND", b""))


def _make_preview(code):
    global _qr_directory
    _qr_directory = tempfile.TemporaryDirectory()
    path = Path(_qr_directory.name) / "pairing.png"
    path.write_bytes(_qr_png(code))
    _previews.load("pairing", str(path), "IMAGE")


class PhoneRotationSettings(bpy.types.PropertyGroup):
    target: bpy.props.PointerProperty(name="Object", type=bpy.types.Object)
    address: bpy.props.StringProperty(name="LAN IPv4", options={"SKIP_SAVE"})


class PHONE_ROTATION_OT_start(bpy.types.Operator):
    bl_idname = "phone_rotation.start"
    bl_label = "Start pairing"
    bl_description = "Create a temporary pairing QR code for this session"

    def execute(self, context):
        global _receiver, _scene, _draw_handle
        _stop()
        settings = context.scene.phone_rotation
        settings.address = settings.address.strip() or default_address()
        if not settings.address:
            self.report({"ERROR"}, "Enter the computer's local IPv4 address.")
            return {"CANCELLED"}
        try:
            _receiver = Receiver(settings.address, _command)
            _scene = context.scene
            _make_preview(_receiver.pairing_code)
            _draw_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_camera, (), "WINDOW", "POST_PIXEL")
            bpy.app.timers.register(_tick)
        except (OSError, ValueError, RuntimeError) as error:
            _stop()
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        _redraw()
        return {"FINISHED"}


class PHONE_ROTATION_OT_stop(bpy.types.Operator):
    bl_idname = "phone_rotation.stop"
    bl_label = "Close connection"

    def execute(self, context):
        _stop()
        _redraw()
        return {"FINISHED"}


class PHONE_ROTATION_PT_panel(bpy.types.Panel):
    bl_label = "Phone Rotation"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Phone Rotation"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.phone_rotation
        layout.prop(settings, "target")
        if _receiver is None:
            layout.prop(settings, "address")
            if not settings.address:
                layout.label(text="Leave blank for automatic IPv4")
            layout.operator("phone_rotation.start", icon="PLAY")
            return
        if _scene != context.scene:
            layout.label(text=f"Active in {_scene.name}", icon="INFO")
        layout.label(text=f"{_receiver.address}:{_receiver.port}")
        if _receiver.authenticated:
            layout.label(text="Phone connected", icon="CHECKMARK")
        else:
            layout.label(text="Scan in the Android app")
            layout.template_icon(icon_value=_previews["pairing"].icon_id, scale=9.0)
        layout.operator("phone_rotation.stop", icon="X")


_CLASSES = (PhoneRotationSettings, PHONE_ROTATION_OT_start,
            PHONE_ROTATION_OT_stop, PHONE_ROTATION_PT_panel)


def register():
    global _previews
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.phone_rotation = bpy.props.PointerProperty(type=PhoneRotationSettings)
    _previews = bpy.utils.previews.new()
    bpy.app.handlers.load_pre.append(_before_file_load)


def unregister():
    global _previews
    _stop()
    bpy.app.handlers.load_pre.remove(_before_file_load)
    bpy.utils.previews.remove(_previews)
    _previews = None
    del bpy.types.Scene.phone_rotation
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
