"""Render the active camera with the 3D View settings and encode a small PNG."""

import binascii
import struct
import time
import zlib

import gpu
import numpy as np

FRAME_INTERVAL = 1 / 15


def png_chunk(kind, data):
    return (struct.pack(">I", len(data)) + kind + data
            + struct.pack(">I", binascii.crc32(kind + data)))


def frame_png(rgba, width, height):
    pixels = np.asarray(rgba, dtype=np.uint8).reshape(height, width, 4)[::-1, :, :3]
    # PNG's Sub filter keeps neighboring RGB pixels compressible.
    rows = np.empty((height, width * 3 + 1), dtype=np.uint8)
    rows[:, 0] = 1
    rows[:, 1:4] = pixels[:, 0, :]
    rows[:, 4:] = (pixels[:, 1:, :] - pixels[:, :-1, :]).reshape(height, -1)
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", header)
            + png_chunk(b"IDAT", zlib.compress(rows, level=1)) + png_chunk(b"IEND", b""))


class CameraPreview:
    def __init__(self):
        self.offscreen = None
        self.context_key = None
        self.next_frame = 0.0
        self.drawing = False
        self.redraw_pending = False

    def close(self):
        if self.offscreen is not None:
            try:
                self.offscreen.free()
            except (ReferenceError, RuntimeError, SystemError):
                pass  # The owning window might already have closed.
        self.offscreen = None
        self.context_key = None

    def capture(self, context, scene, channel):
        if self.drawing or channel.requested_at is None or time.monotonic() < self.next_frame:
            return
        if context.scene != scene or context.region is None or context.region.type != "WINDOW":
            return

        self.drawing = True
        self.redraw_pending = False
        started = time.monotonic()
        try:
            camera = scene.camera
            if camera is None or camera.type != "CAMERA" or camera.data.type not in {"PERSP", "ORTHO"}:
                channel.respond()
                self.next_frame = time.monotonic() + 0.35
                return
            render = scene.render
            aspect_width = render.resolution_x * render.pixel_aspect_x
            aspect_height = render.resolution_y * render.pixel_aspect_y
            scale = min(854 / max(aspect_width, aspect_height), 480 / min(aspect_width, aspect_height), 1)
            width = max(2, round(aspect_width * scale))
            height = max(2, round(aspect_height * scale))
            context_key = (context.window.as_pointer(), width, height)
            if self.context_key != context_key:
                self.close()
                self.offscreen = gpu.types.GPUOffScreen(width, height)
                self.context_key = context_key

            depsgraph = context.evaluated_depsgraph_get()
            camera = camera.evaluated_get(depsgraph)
            view = camera.matrix_world.normalized().inverted()
            projection = camera.calc_matrix_camera(
                depsgraph, x=render.resolution_x, y=render.resolution_y,
                scale_x=render.pixel_aspect_x, scale_y=render.pixel_aspect_y)
            space = context.space_data
            overlays_visible = space.overlay.show_overlays
            try:
                if overlays_visible:
                    space.overlay.show_overlays = False
                self.offscreen.draw_view3d(
                    scene, context.view_layer, space, context.region, view, projection,
                    do_color_management=True, draw_background=True)
            finally:
                if overlays_visible:
                    space.overlay.show_overlays = True
            with self.offscreen.bind():
                buffer = gpu.state.active_framebuffer_get().read_color(
                    0, 0, width, height, 4, 0, "UBYTE")
            # Read the linear framebuffer before reshaping it into scanlines.
            buffer.dimensions = width * height * 4
            channel.respond(frame_png(buffer, width, height))
            self.next_frame = started + FRAME_INTERVAL
        except (RuntimeError, ReferenceError, ValueError, SystemError) as error:
            print(f"Phone Rotation camera preview: {error}")
            channel.respond()
            self.next_frame = time.monotonic() + 1
        finally:
            self.drawing = False
