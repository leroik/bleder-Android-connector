"""Small, bounded TCP receiver. The caller polls it on Blender's main thread."""

import hmac
import ipaddress
import math
import secrets
import socket
import time

from .video import VideoChannel


class Receiver:
    def __init__(self, address, on_command):
        self.address = str(ipaddress.IPv4Address(address))
        if ipaddress.IPv4Address(self.address).is_unspecified:
            raise ValueError("Choose the computer's LAN IPv4 address.")
        self.on_command = on_command
        self.token = secrets.token_urlsafe(18)
        self.listener = socket.socket()
        try:
            self.listener.bind((self.address, 0))
            self.listener.listen(2)
            self.listener.setblocking(False)
        except OSError:
            self.listener.close()
            raise
        self.port = self.listener.getsockname()[1]
        self.client = None
        self.candidate = None
        self.candidate_input = bytearray()
        self.candidate_at = 0.0
        self.video = VideoChannel()
        self.authenticated = False
        self.incoming = bytearray()
        self.outgoing = bytearray()
        self.received_at = 0.0

    @property
    def pairing_code(self):
        return f"br1:{self.address}:{self.port}:{self.token}"

    def disconnect(self):
        if self.client is not None:
            self.client.close()
        self.client = None
        self.video.close()
        self.authenticated = False
        self.incoming.clear()
        self.outgoing.clear()

    def _close_candidate(self):
        if self.candidate is not None:
            self.candidate.close()
        self.candidate = None
        self.candidate_input.clear()

    def close(self):
        self.disconnect()
        self._close_candidate()
        self.listener.close()

    def _poll_candidate(self):
        now = time.monotonic()
        try:
            if self.candidate is None:
                self.candidate, _ = self.listener.accept()
                self.candidate.setblocking(False)
                self.candidate.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                self.candidate_at = now
            if now - self.candidate_at > 2:
                self._close_candidate()
                return
            data = self.candidate.recv(256)
            if not data:
                self._close_candidate()
                return
            self.candidate_input.extend(data)
            if len(self.candidate_input) > 160:
                self._close_candidate()
                return
            if not self.candidate_input.endswith(b"\n"):
                return
            command, token = bytes(self.candidate_input).decode("ascii").split()
            if not hmac.compare_digest(token, self.token):
                self._close_candidate()
                return
            if command == "hello" and self.client is None:
                self.client = self.candidate
                self.authenticated = True
                self.received_at = now
                self.on_command("begin", None)
                self.outgoing.extend(b"ok\n")
            elif (command == "video" and self.client is not None
                  and self.candidate.getpeername()[0] == self.client.getpeername()[0]):
                self.video.attach(self.candidate)
            else:
                self._close_candidate()
                return
            self.candidate = None
            self.candidate_input.clear()
        except BlockingIOError:
            pass
        except (OSError, ValueError):
            self._close_candidate()

    def poll(self):
        self._poll_control()
        self._poll_candidate()
        self.video.poll()

    def _poll_control(self):
        if self.client is None:
            return
        if time.monotonic() - self.received_at > 12:
            self.disconnect()
            return
        try:
            try:
                data = self.client.recv(1024)
                if not data:
                    self.disconnect()
                    return
                self.incoming.extend(data)
            except BlockingIOError:
                pass
            if len(self.incoming) > 2048:
                raise ValueError("Input buffer exceeded")
            for _ in range(24):
                end = self.incoming.find(b"\n")
                if end < 0:
                    break
                line = bytes(self.incoming[:end]).decode("ascii")
                del self.incoming[:end + 1]
                self.outgoing.extend(self.handle(line) + b"\n")
                self.received_at = time.monotonic()
            if len(self.outgoing) > 2048:
                raise ValueError("Output buffer exceeded")
            if self.outgoing:
                try:
                    sent = self.client.send(self.outgoing)
                    del self.outgoing[:sent]
                except BlockingIOError:
                    pass
        except (OSError, ValueError):
            self.disconnect()

    def handle(self, line):
        if len(line) > 160:
            raise ValueError("Request too long")
        parts = line.split()
        if parts in (["begin"], ["begin-camera"], ["stop"]):
            return self.on_command(parts[0], None)
        if parts == ["ping"]:
            return b"ok"
        if len(parts) == 5 and parts[0] in ("move", "stop"):
            values = tuple(float(value) for value in parts[1:])
            if all(math.isfinite(value) and abs(value) <= 1.01 for value in values):
                if sum(value * value for value in values) > 0.01:
                    return self.on_command(parts[0], values)
        raise ValueError("Invalid rotation command")


def default_address():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        try:
            probe.connect(("192.0.2.1", 9))
            return probe.getsockname()[0]
        except OSError:
            return ""
